#!/bin/bash

echo "=========================================="
echo "Setting up Data Ingestion Service"
echo "=========================================="

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Initialize database
echo "Initializing database..."
python -c "from app.database import init_db; import asyncio; asyncio.run(init_db())"

echo ""
echo "=========================================="
echo "Setup complete!"
echo "=========================================="
echo ""
echo "To run the application:"
echo "  1. Start API server:    uvicorn app.main:app --reload"
echo "  2. Start aggregator:    python -m app.aggregator"
echo "  3. Run tests:           pytest -v"
echo ""
echo "API docs will be at: http://localhost:8000/docs"
echo "=========================================="
