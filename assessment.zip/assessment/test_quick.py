#!/usr/bin/env python3
"""Quick verification script to test the API"""
import asyncio
import httpx
from datetime import datetime, timezone

async def test_api():
    base_url = "http://localhost:8000"
    
    async with httpx.AsyncClient() as client:
        print("Testing API endpoints...")
        
        # Test health
        print("\n1. Testing /health...")
        r = await client.get(f"{base_url}/health")
        print(f"   Status: {r.status_code}, Response: {r.json()}")
        
        # Test ready
        print("\n2. Testing /ready...")
        r = await client.get(f"{base_url}/ready")
        print(f"   Status: {r.status_code}, Response: {r.json()}")
        
        # Create single event
        print("\n3. Testing POST /events...")
        event = {
            "event_id": "test_001",
            "tenant_id": "test_tenant",
            "source": "web",
            "event_type": "click",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": {"test": "data"}
        }
        r = await client.post(f"{base_url}/events", json=event)
        print(f"   Status: {r.status_code}")
        if r.status_code == 201:
            print(f"   Created: {r.json()['event_id']}")
        
        # Test idempotency
        print("\n4. Testing idempotency (duplicate event)...")
        r = await client.post(f"{base_url}/events", json=event)
        print(f"   Status: {r.status_code} (should be 201)")
        
        # Query events
        print("\n5. Testing GET /events...")
        r = await client.get(f"{base_url}/events", params={"tenant_id": "test_tenant"})
        print(f"   Status: {r.status_code}, Found: {len(r.json())} events")
        
        print("\n✅ All tests passed!")

if __name__ == "__main__":
    print("Make sure the API server is running: uvicorn app.main:app --reload")
    print("=" * 60)
    asyncio.run(test_api())
