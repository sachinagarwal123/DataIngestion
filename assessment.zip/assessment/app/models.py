from sqlalchemy import Column, String, DateTime, Integer, JSON, Index, UniqueConstraint
from datetime import datetime
from app.database import Base

class Event(Base):
    __tablename__ = "events"
    
    event_id = Column(String, primary_key=True)
    tenant_id = Column(String, nullable=False, index=True)
    source = Column(String, nullable=False, index=True)
    event_type = Column(String, nullable=False, index=True)
    timestamp = Column(DateTime, nullable=False, index=True)
    payload = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index('idx_tenant_timestamp', 'tenant_id', 'timestamp'),
        Index('idx_tenant_source_type', 'tenant_id', 'source', 'event_type'),
    )

class Aggregate(Base):
    __tablename__ = "aggregates"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String, nullable=False, index=True)
    bucket_start = Column(DateTime, nullable=False, index=True)
    bucket_size = Column(String, nullable=False)
    source = Column(String, nullable=True)
    event_type = Column(String, nullable=True)
    count = Column(Integer, default=0, nullable=False)
    first_seen = Column(DateTime, nullable=False)
    last_seen = Column(DateTime, nullable=False)
    
    __table_args__ = (
        UniqueConstraint('tenant_id', 'bucket_start', 'bucket_size', 'source', 'event_type', 
                        name='uq_aggregate'),
        Index('idx_tenant_bucket', 'tenant_id', 'bucket_start'),
    )
