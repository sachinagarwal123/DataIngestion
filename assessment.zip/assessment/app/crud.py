from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from sqlalchemy.exc import IntegrityError
from app.models import Event, Aggregate
from app.schemas import EventCreate
from datetime import datetime
from typing import List, Optional

async def create_event_idempotent(db: AsyncSession, event: EventCreate) -> Event:
    """Insert event with idempotency - returns existing if duplicate"""
    db_event = Event(**event.model_dump())
    db.add(db_event)
    try:
        await db.commit()
        await db.refresh(db_event)
        return db_event
    except IntegrityError:
        # Duplicate - fetch and return existing
        await db.rollback()
        # Use a fresh query after rollback
        result = await db.execute(
            select(Event).where(Event.event_id == event.event_id)
        )
        existing = result.scalar_one_or_none()
        if existing:
            return existing
        # If still not found, wait a tiny bit and retry once
        import asyncio
        await asyncio.sleep(0.001)
        result = await db.execute(
            select(Event).where(Event.event_id == event.event_id)
        )
        return result.scalar_one()

async def bulk_create_events(db: AsyncSession, events: List[EventCreate]) -> int:
    """Bulk insert with idempotency handling"""
    if not events:
        return 0
    
    inserted = 0
    seen_ids = set()
    
    for event in events:
        # Skip duplicates within the batch
        if event.event_id in seen_ids:
            continue
        seen_ids.add(event.event_id)
        
        db_event = Event(**event.model_dump())
        db.add(db_event)
        try:
            await db.flush()
            inserted += 1
        except IntegrityError:
            await db.rollback()
    
    await db.commit()
    return inserted

async def get_events(
    db: AsyncSession,
    tenant_id: str,
    source: Optional[str] = None,
    event_type: Optional[str] = None,
    from_time: Optional[datetime] = None,
    to_time: Optional[datetime] = None,
    page: int = 1,
    page_size: int = 100
) -> List[Event]:
    """Query events with filters and pagination"""
    query = select(Event).where(Event.tenant_id == tenant_id)
    
    if source:
        query = query.where(Event.source == source)
    if event_type:
        query = query.where(Event.event_type == event_type)
    if from_time:
        query = query.where(Event.timestamp >= from_time)
    if to_time:
        query = query.where(Event.timestamp <= to_time)
    
    query = query.order_by(Event.timestamp.desc(), Event.event_id)
    query = query.offset((page - 1) * page_size).limit(page_size)
    
    result = await db.execute(query)
    return result.scalars().all()

async def get_metrics(
    db: AsyncSession,
    tenant_id: str,
    bucket_size: str,
    source: Optional[str] = None,
    event_type: Optional[str] = None,
    from_time: Optional[datetime] = None,
    to_time: Optional[datetime] = None
) -> List[Aggregate]:
    """Query aggregated metrics"""
    query = select(Aggregate).where(
        and_(
            Aggregate.tenant_id == tenant_id,
            Aggregate.bucket_size == bucket_size
        )
    )
    
    if source:
        query = query.where(Aggregate.source == source)
    if event_type:
        query = query.where(Aggregate.event_type == event_type)
    if from_time:
        query = query.where(Aggregate.bucket_start >= from_time)
    if to_time:
        query = query.where(Aggregate.bucket_start <= to_time)
    
    query = query.order_by(Aggregate.bucket_start.desc())
    
    result = await db.execute(query)
    return result.scalars().all()
