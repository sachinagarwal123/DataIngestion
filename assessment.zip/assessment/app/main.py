from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db, init_db, engine
from app.schemas import EventCreate, EventResponse, BulkEventRequest, EventQuery, MetricsQuery, MetricResponse
from app import crud
from typing import List
import asyncio

app = FastAPI(title="Data Ingestion and Aggregation Service")

@app.on_event("startup")
async def startup():
    await init_db()

@app.on_event("shutdown")
async def shutdown():
    await engine.dispose()

@app.get("/health")
async def health():
    return {"status": "ok"}

@app.get("/ready")
async def ready(db: AsyncSession = Depends(get_db)):
    try:
        await db.execute(select(1))
        return {"status": "ready", "database": "connected"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Database not ready: {str(e)}")

@app.post("/events", response_model=EventResponse, status_code=status.HTTP_201_CREATED)
async def create_event(event: EventCreate, db: AsyncSession = Depends(get_db)):
    """Create single event with idempotency"""
    db_event = await crud.create_event_idempotent(db, event)
    return db_event

@app.post("/events/bulk", status_code=status.HTTP_201_CREATED)
async def create_events_bulk(request: BulkEventRequest, db: AsyncSession = Depends(get_db)):
    """Bulk create events (up to 5000) with idempotency"""
    if len(request.events) > 5000:
        raise HTTPException(status_code=400, detail="Maximum 5000 events allowed")
    
    inserted = await crud.bulk_create_events(db, request.events)
    return {"inserted": inserted, "total": len(request.events)}

@app.get("/events", response_model=List[EventResponse])
async def get_events(
    tenant_id: str,
    source: str = None,
    event_type: str = None,
    from_time: str = None,
    to_time: str = None,
    page: int = 1,
    page_size: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Query events with filters and pagination"""
    from datetime import datetime
    
    from_dt = datetime.fromisoformat(from_time) if from_time else None
    to_dt = datetime.fromisoformat(to_time) if to_time else None
    
    events = await crud.get_events(
        db, tenant_id, source, event_type, from_dt, to_dt, page, page_size
    )
    return events

@app.get("/metrics", response_model=List[MetricResponse])
async def get_metrics(
    tenant_id: str,
    bucket_size: str,
    source: str = None,
    event_type: str = None,
    from_time: str = None,
    to_time: str = None,
    db: AsyncSession = Depends(get_db)
):
    """Query aggregated metrics"""
    from datetime import datetime
    
    if bucket_size not in ["minute", "hour"]:
        raise HTTPException(status_code=400, detail="bucket_size must be 'minute' or 'hour'")
    
    from_dt = datetime.fromisoformat(from_time) if from_time else None
    to_dt = datetime.fromisoformat(to_time) if to_time else None
    
    metrics = await crud.get_metrics(
        db, tenant_id, bucket_size, source, event_type, from_dt, to_dt
    )
    return metrics
