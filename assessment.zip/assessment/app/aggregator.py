import asyncio
from datetime import datetime, timedelta
from sqlalchemy import select, and_
from sqlalchemy.dialects.postgresql import insert as pg_insert
from app.database import AsyncSessionLocal, init_db
from app.models import Event, Aggregate

def get_bucket_start(timestamp: datetime, bucket_size: str) -> datetime:
    """Calculate bucket start time"""
    if bucket_size == "minute":
        return timestamp.replace(second=0, microsecond=0)
    elif bucket_size == "hour":
        return timestamp.replace(minute=0, second=0, microsecond=0)
    raise ValueError(f"Invalid bucket_size: {bucket_size}")

async def aggregate_events(bucket_size: str = "minute", lookback_minutes: int = 60):
    """Aggregate events into time buckets with idempotency"""
    async with AsyncSessionLocal() as db:
        cutoff = datetime.utcnow() - timedelta(minutes=lookback_minutes)
        
        # Get events to aggregate
        query = select(Event).where(Event.timestamp >= cutoff)
        result = await db.execute(query)
        events = result.scalars().all()
        
        if not events:
            print(f"No events to aggregate")
            return
        
        # Group events by bucket
        aggregates = {}
        for event in events:
            bucket_start = get_bucket_start(event.timestamp, bucket_size)
            key = (event.tenant_id, bucket_start, bucket_size, event.source, event.event_type)
            
            if key not in aggregates:
                aggregates[key] = {
                    'tenant_id': event.tenant_id,
                    'bucket_start': bucket_start,
                    'bucket_size': bucket_size,
                    'source': event.source,
                    'event_type': event.event_type,
                    'count': 0,
                    'first_seen': event.timestamp,
                    'last_seen': event.timestamp
                }
            
            agg = aggregates[key]
            agg['count'] += 1
            agg['first_seen'] = min(agg['first_seen'], event.timestamp)
            agg['last_seen'] = max(agg['last_seen'], event.timestamp)
        
        # Upsert aggregates (SQLite compatible)
        for agg_data in aggregates.values():
            # Check if aggregate exists
            query = select(Aggregate).where(
                and_(
                    Aggregate.tenant_id == agg_data['tenant_id'],
                    Aggregate.bucket_start == agg_data['bucket_start'],
                    Aggregate.bucket_size == agg_data['bucket_size'],
                    Aggregate.source == agg_data['source'],
                    Aggregate.event_type == agg_data['event_type']
                )
            )
            result = await db.execute(query)
            existing = result.scalar_one_or_none()
            
            if existing:
                # Update existing
                existing.count += agg_data['count']
                existing.first_seen = min(existing.first_seen, agg_data['first_seen'])
                existing.last_seen = max(existing.last_seen, agg_data['last_seen'])
            else:
                # Insert new
                db.add(Aggregate(**agg_data))
        
        await db.commit()
        print(f"Aggregated {len(events)} events into {len(aggregates)} buckets")

async def run_aggregator():
    """Run aggregator in loop"""
    await init_db()
    print("Aggregator started")
    
    while True:
        try:
            await aggregate_events(bucket_size="minute", lookback_minutes=60)
            await aggregate_events(bucket_size="hour", lookback_minutes=1440)
            await asyncio.sleep(60)
        except Exception as e:
            print(f"Aggregation error: {e}")
            await asyncio.sleep(10)

if __name__ == "__main__":
    asyncio.run(run_aggregator())
