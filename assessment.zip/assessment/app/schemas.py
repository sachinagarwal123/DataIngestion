from pydantic import BaseModel, Field, field_validator
from datetime import datetime
from typing import Optional, List, Dict, Any

class EventCreate(BaseModel):
    event_id: str
    tenant_id: str
    source: str
    event_type: str
    timestamp: datetime
    payload: Dict[str, Any]
    
    @field_validator('timestamp')
    @classmethod
    def validate_timestamp(cls, v):
        if v.tzinfo is None:
            raise ValueError('timestamp must be timezone-aware (UTC)')
        return v.replace(tzinfo=None)

class EventResponse(BaseModel):
    event_id: str
    tenant_id: str
    source: str
    event_type: str
    timestamp: datetime
    payload: Dict[str, Any]
    created_at: datetime
    
    class Config:
        from_attributes = True

class BulkEventRequest(BaseModel):
    events: List[EventCreate] = Field(..., max_length=5000)

class EventQuery(BaseModel):
    tenant_id: str
    source: Optional[str] = None
    event_type: Optional[str] = None
    from_time: Optional[datetime] = Field(None, alias="from")
    to_time: Optional[datetime] = Field(None, alias="to")
    page: int = Field(1, ge=1)
    page_size: int = Field(100, ge=1, le=1000)

class MetricsQuery(BaseModel):
    tenant_id: str
    bucket_size: str = Field(..., pattern="^(minute|hour)$")
    source: Optional[str] = None
    event_type: Optional[str] = None
    from_time: Optional[datetime] = Field(None, alias="from")
    to_time: Optional[datetime] = Field(None, alias="to")

class MetricResponse(BaseModel):
    tenant_id: str
    bucket_start: datetime
    bucket_size: str
    source: Optional[str]
    event_type: Optional[str]
    count: int
    first_seen: datetime
    last_seen: datetime
    
    class Config:
        from_attributes = True
