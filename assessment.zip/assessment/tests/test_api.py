import pytest
from datetime import datetime, timezone
from httpx import AsyncClient

@pytest.mark.asyncio
async def test_health_endpoint(client: AsyncClient):
    response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

@pytest.mark.asyncio
async def test_ready_endpoint(client: AsyncClient):
    response = await client.get("/ready")
    assert response.status_code == 200
    assert "database" in response.json()

@pytest.mark.asyncio
async def test_create_event_idempotent(client: AsyncClient):
    """Test idempotent event creation"""
    event_data = {
        "event_id": "evt_001",
        "tenant_id": "tenant_1",
        "source": "web",
        "event_type": "click",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "payload": {"page": "home"}
    }
    
    # First insert
    response1 = await client.post("/events", json=event_data)
    assert response1.status_code == 201
    
    # Duplicate insert - should not fail
    response2 = await client.post("/events", json=event_data)
    assert response2.status_code == 201
    assert response1.json()["event_id"] == response2.json()["event_id"]

@pytest.mark.asyncio
async def test_bulk_insert(client: AsyncClient):
    """Test bulk event insertion"""
    events = [
        {
            "event_id": f"evt_{i}",
            "tenant_id": "tenant_1",
            "source": "mobile",
            "event_type": "view",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": {"screen": f"screen_{i}"}
        }
        for i in range(100)
    ]
    
    response = await client.post("/events/bulk", json={"events": events})
    assert response.status_code == 201
    data = response.json()
    assert data["total"] == 100
    assert data["inserted"] == 100

@pytest.mark.asyncio
async def test_bulk_insert_with_duplicates(client: AsyncClient):
    """Test bulk insert idempotency"""
    events = [
        {
            "event_id": "evt_dup",
            "tenant_id": "tenant_1",
            "source": "web",
            "event_type": "click",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": {}
        }
        for _ in range(10)
    ]
    
    response = await client.post("/events/bulk", json={"events": events})
    assert response.status_code == 201
    data = response.json()
    assert data["inserted"] == 1  # Only one inserted due to duplicates

@pytest.mark.asyncio
async def test_bulk_insert_size_limit(client: AsyncClient):
    """Test bulk insert rejects oversized payloads"""
    events = [
        {
            "event_id": f"evt_{i}",
            "tenant_id": "tenant_1",
            "source": "web",
            "event_type": "click",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": {}
        }
        for i in range(5001)
    ]
    
    response = await client.post("/events/bulk", json={"events": events})
    assert response.status_code == 422  # Validation error

@pytest.mark.asyncio
async def test_query_events_with_filters(client: AsyncClient):
    """Test event querying with filters"""
    # Insert test events
    base_time = datetime.now(timezone.utc)
    for i in range(5):
        await client.post("/events", json={
            "event_id": f"query_evt_{i}",
            "tenant_id": "tenant_query",
            "source": "web" if i % 2 == 0 else "mobile",
            "event_type": "click",
            "timestamp": base_time.isoformat(),
            "payload": {}
        })
    
    # Query all events for tenant
    response = await client.get("/events", params={"tenant_id": "tenant_query"})
    assert response.status_code == 200
    assert len(response.json()) == 5
    
    # Query with source filter
    response = await client.get("/events", params={
        "tenant_id": "tenant_query",
        "source": "web"
    })
    assert response.status_code == 200
    assert len(response.json()) == 3

@pytest.mark.asyncio
async def test_query_events_pagination(client: AsyncClient):
    """Test event pagination"""
    # Insert 25 events
    for i in range(25):
        await client.post("/events", json={
            "event_id": f"page_evt_{i}",
            "tenant_id": "tenant_page",
            "source": "web",
            "event_type": "view",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": {}
        })
    
    # Get first page
    response = await client.get("/events", params={
        "tenant_id": "tenant_page",
        "page": 1,
        "page_size": 10
    })
    assert response.status_code == 200
    assert len(response.json()) == 10
    
    # Get second page
    response = await client.get("/events", params={
        "tenant_id": "tenant_page",
        "page": 2,
        "page_size": 10
    })
    assert response.status_code == 200
    assert len(response.json()) == 10

@pytest.mark.asyncio
async def test_concurrent_event_creation(client: AsyncClient):
    """Test concurrent event creation safety"""
    event_data = {
        "event_id": "concurrent_evt",
        "tenant_id": "tenant_1",
        "source": "web",
        "event_type": "click",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "payload": {}
    }
    
    # Create same event multiple times (tests idempotency)
    for _ in range(10):
        response = await client.post("/events", json=event_data)
        assert response.status_code == 201
    
    # Verify only one event was created
    response = await client.get("/events", params={"tenant_id": "tenant_1"})
    events = [e for e in response.json() if e["event_id"] == "concurrent_evt"]
    assert len(events) == 1

@pytest.mark.asyncio
async def test_timestamp_validation(client: AsyncClient):
    """Test timestamp must be timezone-aware"""
    event_data = {
        "event_id": "evt_tz",
        "tenant_id": "tenant_1",
        "source": "web",
        "event_type": "click",
        "timestamp": "2024-01-01T12:00:00",  # No timezone
        "payload": {}
    }
    
    response = await client.post("/events", json=event_data)
    assert response.status_code == 422  # Validation error
